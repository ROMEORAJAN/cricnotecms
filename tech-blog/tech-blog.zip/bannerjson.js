const bannerdata = [
    {
        discription: "",
        title: "",
        image: "",
        date: "",
        speakername: ""
    },
    {
        discription: "",
        title: "",
        image: "",
        date: "",
        speakername: ""
    },
    {
        discription: "",
        title: "",
        image: "",
        date: "",
        speakername: ""
    },
]