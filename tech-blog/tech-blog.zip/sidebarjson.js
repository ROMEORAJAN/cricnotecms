const sidebar = [{
    "sidebarimage": "",
    "trendone": {
        imageone: "",
        trendheading: "",
    },
    "trendtwo": {
        imagetwo: "",
        trendheading: "",
    },
    "trendthree": {
        imagethree: "",
        trendheading: "",
    },
    "popularpost": {
        "popularone": {
            popularimg: "",
            popularheading: "",
            dateofnews: "",
        },
        "populartwo": {
            popularimg: "",
            popularheading: "",
            dateofnews: "",
        },
        "popularthree": {
            popularimg: "",
            popularheading: "",
            dateofnews: "",
        },
    },
    "recentreview": {
        "recentone": {
            recentimageone: "",
            recentheading: "",
            starrating: "",
        },
        "recenttwo": {
            recentimagetwo: "",
            recentheading: "",
            starrating: "",
        },
        "recentthree": {
            recentimagethree: "",
            recentheading: "",
            starrating: "",
        },
    },
    "followus": {
        facebookcount: "",
        twittercount: "",
        googlecount: "",
        othercount: "",
    },
    "footerimage": "",
}]